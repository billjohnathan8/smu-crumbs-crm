﻿"""Compatibility module for the direct Lambda runtime.

FastAPI/Mangum request handling was removed. The service now routes API Gateway
proxy events directly through ``app.lambda_router.LambdaRouter``.
"""

from .lambda_router import LambdaRouter

__all__ = ["LambdaRouter"]
